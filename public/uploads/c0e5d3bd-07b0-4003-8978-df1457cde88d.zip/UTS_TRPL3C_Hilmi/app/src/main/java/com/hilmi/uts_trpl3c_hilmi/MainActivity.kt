package com.hilmi.uts_trpl3c_hilmi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val noRekamMedis =
        val namaPasien =
        val tanggalPeriksa =
        val namaDokter =
        val hasilDiagnosa =
        val biayaDokter =
        val biayaObat =
        val biayaLabor =
        val biayaDaftar =
        val checkLabor =